package com.swesurvey.surveybackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveybackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
