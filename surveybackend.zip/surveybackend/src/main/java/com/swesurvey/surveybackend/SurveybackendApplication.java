/* 
<!-- Team Members
 Name: Ashrith Bhooka Ravinandan
 Gno. G01455956

 Name:Rishith Reddy Pendli
 Gno. G01411978

 Name: Sathwik Reddy Bojja
 Gno. G01461462 
 
 This is the starting point of the backend application, runs on the port 8080
 -->
*/

package com.swesurvey.surveybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurveybackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurveybackendApplication.class, args);
	}

}
